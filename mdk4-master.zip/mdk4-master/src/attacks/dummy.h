#ifndef HAVE_DUMMY_H
#define HAVE_DUMMY_H

#include "attacks.h"

void call_dummy();

void call_dummy2();

struct attacks load_dummy();

#endif