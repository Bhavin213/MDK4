#ifndef HAVE_IEEE80211S_H
#define HAVE_IEEE80211S_H

#include "attacks.h"

struct attacks load_ieee80211s();

#endif